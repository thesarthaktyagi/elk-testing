import logging
import logstash
import random
test_logger = logging.getLogger('Service Name')
test_logger.setLevel(logging.DEBUG)
test_logger.addHandler(logstash.TCPLogstashHandler(
    '127.0.0.1', 5000, version=1))
extra = {
    'app_name': "Service_Name"
}
# This code logs 10 times
test_logger.error("""
test_logger = logging.getLogger('Service Name')
test_logger.setLevel(logging.DEBUG)
test_logger.addHandler(logstash.TCPLogstashHandler(
    '127.0.0.1', 5000, version=1))
""")
